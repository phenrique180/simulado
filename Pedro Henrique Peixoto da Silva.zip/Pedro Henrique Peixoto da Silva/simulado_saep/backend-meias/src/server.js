// server.js — mini backend "meia meia meia" (Prova SAEP)
// npm i express cors pg
console.log(">>> SERVER.JS QUE ESTÁ RODANDO <<<");

const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();

// ⚠️ USE A SENHA REAL DO POSTGRES (a mesma usada no pgAdmin)
const pool = new Pool({
  user: 'postgres',
  password: 'senai', // <-- confirme essa senha
  host: 'localhost',
  port: 5432,
  database: 'saep_db',
});

app.use(cors());
app.use(express.json());

// Teste de conexão ao iniciar
pool.connect()
  .then(() => console.log("Conectado ao PostgreSQL com sucesso."))
  .catch(err => {
    console.error("❌ ERRO AO CONECTAR NO BANCO:");
    console.error(err);
  });

// util simples
const ok = (res, data) => res.json(data);

const fail = (res, err, code = 500) => {
  console.error("ERRO:", err);
  const msg = typeof err === "string" ? err : err?.message || "Erro interno";
  res.status(code).json({ error: msg });
};

// -----------------------------
// HEALTHCHECK
// -----------------------------
app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    ok(res, { status: 'ok' });
  } catch (e) { fail(res, e); }
});

// -----------------------------
// USUÁRIOS
// -----------------------------
app.post('/usuarios', async (req, res) => {
  const { nome, email, senha } = req.body || {};
  if (!nome || !email || !senha)
    return fail(res, 'Campos obrigatórios: nome, email, senha', 400);

  try {
    const q = `
      INSERT INTO usuarios (nome, email, senha)
      VALUES ($1,$2,$3)
      RETURNING id, nome, email
    `;
    const r = await pool.query(q, [nome, email, senha]);
    ok(res, r.rows[0]);

  } catch (e) {
    if (String(e?.message).includes('unique'))
      return fail(res, 'E-mail já cadastrado', 409);

    fail(res, e);
  }
});

// LOGIN
app.post('/auth/login', async (req, res) => {
  const { email, senha } = req.body || {};

  if (!email || !senha)
    return fail(res, 'Informe email e senha', 400);

  try {
    const r = await pool.query(
      'SELECT id, nome, email FROM usuarios WHERE email=$1 AND senha=$2',
      [email, senha]
    );

    if (r.rows.length === 0)
      return fail(res, 'Credenciais inválidas', 401);

    ok(res, r.rows[0]);

  } catch (e) {
    fail(res, e);
  }
});

// ---------------------------------------------------------------------
// PRODUTOS / MOVIMENTAÇÕES (mesmo código, sem alterações críticas)
// ---------------------------------------------------------------------

// ---------------------------------------------
// MOVIMENTAÇÕES DE ESTOQUE
// ---------------------------------------------
app.post('/movimentacoes', async (req, res) => {
  const {
    produto_id,
    usuario_id,
    tipo,
    quantidade,
    data_movimentacao = null,
    observacao = null
  } = req.body || {};

  if (!produto_id || !usuario_id || !tipo || !quantidade)
    return fail(res, "Campos obrigatórios ausentes", 400);

  if (!["entrada", "saida"].includes(tipo))
    return fail(res, "Tipo inválido (use entrada|saida)", 400);

  try {
    // buscar produto atual
    const r1 = await pool.query(
      `SELECT id, nome, quantidade, estoque_minimo
         FROM produtos
        WHERE id=$1`,
      [produto_id]
    );

    if (!r1.rows.length)
      return fail(res, "Produto não encontrado", 404);

    const prod = r1.rows[0];
    let novoSaldo = Number(prod.quantidade);

    // aplicar movimentação
    if (tipo === "entrada") novoSaldo += Number(quantidade);
    else if (tipo === "saida") {
      if (novoSaldo - Number(quantidade) < 0)
        return fail(res, "Saldo insuficiente", 400);

      novoSaldo -= Number(quantidade);
    }

    // atualizar quantidade do produto
    await pool.query(
      `UPDATE produtos SET quantidade=$1 WHERE id=$2`,
      [novoSaldo, produto_id]
    );

    const abaixo_do_minimo = novoSaldo < prod.estoque_minimo;

    // registrar movimentação
    await pool.query(
      `INSERT INTO movimentacoes
        (produto_id, usuario_id, tipo, quantidade, data_movimentacao, observacao)
       VALUES ($1,$2,$3,$4,$5,$6)`,
      [
        produto_id,
        usuario_id,
        tipo,
        quantidade,
        data_movimentacao,
        observacao
      ]
    );

    ok(res, {
      success: true,
      produto: {
        ...prod,
        quantidade: novoSaldo,
        abaixo_do_minimo
      }
    });

  } catch (e) {
    fail(res, e);
  }
});


app.get('/produtos', async (req, res) => {
  const q = (req.query.q || '').trim();
  const hasQ = q.length > 0;
  const sql =
    `SELECT id, nome, quantidade, estoque_minimo,
            (quantidade < estoque_minimo) AS abaixo_do_minimo
       FROM produtos
      ${hasQ ? 'WHERE lower(nome) LIKE lower($1)' : ''}
      ORDER BY nome ASC`;
  try {
    const args = hasQ ? [`%${q}%`] : [];
    const r = await pool.query(sql, args);
    ok(res, r.rows);
  } catch (e) { fail(res, e); }
});

// obter 1 produto
app.get('/produtos/:id', async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT id, nome, quantidade, estoque_minimo,
              (quantidade < estoque_minimo) AS abaixo_do_minimo
         FROM produtos WHERE id=$1`,
      [req.params.id]
    );
    if (!r.rows.length) return fail(res, 'Produto não encontrado', 404);
    ok(res, r.rows[0]);
  } catch (e) { fail(res, e); }
});

// criar produto
app.post('/produtos', async (req, res) => {
  const { nome, quantidade = 0, estoque_minimo = 0 } = req.body || {};
  if (!nome) return fail(res, 'Campo obrigatório: nome', 400);
  try {
    const r = await pool.query(
      `INSERT INTO produtos (nome, quantidade, estoque_minimo)
       VALUES ($1,$2,$3)
       RETURNING id, nome, quantidade, estoque_minimo`,
      [nome, Number(quantidade) || 0, Number(estoque_minimo) || 0]
    );
    ok(res, r.rows[0]);
  } catch (e) { fail(res, e); }
});

// atualizar produto
app.put('/produtos/:id', async (req, res) => {
  const { nome, quantidade, estoque_minimo } = req.body || {};
  try {
    const r = await pool.query(
      `UPDATE produtos
          SET nome = COALESCE($1, nome),
              quantidade = COALESCE($2, quantidade),
              estoque_minimo = COALESCE($3, estoque_minimo)
        WHERE id=$4
      RETURNING id, nome, quantidade, estoque_minimo`,
      [nome ?? null, quantidade ?? null, estoque_minimo ?? null, req.params.id]
    );
    if (!r.rows.length) return fail(res, 'Produto não encontrado', 404);
    ok(res, r.rows[0]);
  } catch (e) { fail(res, e); }
});

// deletar produto
app.delete('/produtos/:id', async (req, res) => {
  try {
    const r = await pool.query(
      'DELETE FROM produtos WHERE id=$1 RETURNING id',
      [req.params.id]
    );
    if (!r.rows.length) return fail(res, 'Produto não encontrado', 404);
    ok(res, { message: 'Produto excluído' });
  } catch (e) { fail(res, e); }
});

// -----------------------------
// START
// -----------------------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
